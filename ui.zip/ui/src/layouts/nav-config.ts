import type { ComponentType } from "react"
import {
  BoxesIcon,
  Building2,
  ComponentIcon,
  FileKey2Icon,
  KeyRound,
  LockKeyholeIcon,
  PickaxeIcon,
  ServerIcon,
  SprayCanIcon,
  TagsIcon,
  User2,
  Users,
} from "lucide-react"
import { AiOutlineCluster } from "react-icons/ai"
import { GrUserWorker } from "react-icons/gr"
import { MdOutlineDns } from "react-icons/md"
import { SiSwagger } from "react-icons/si"
import { TbLoadBalancer } from "react-icons/tb"

export type NavItem = {
  to: string
  label: string
  icon: ComponentType<{ className?: string }>
  target?: string
}

export const mainNav: NavItem[] = [
  { to: "/clusters", label: "Clusters", icon: AiOutlineCluster },
  { to: "/load-balancers", label: "Load Balancers", icon: TbLoadBalancer },
  { to: "/dns", label: "DNS", icon: MdOutlineDns },
  { to: "/node-pools", label: "Node Pools", icon: BoxesIcon },
  { to: "/annotations", label: "Annotations", icon: ComponentIcon },
  { to: "/labels", label: "Labels", icon: TagsIcon },
  { to: "/taints", label: "Taints", icon: SprayCanIcon },
  { to: "/servers", label: "Servers", icon: ServerIcon },
  { to: "/ssh", label: "SSH Keys", icon: FileKey2Icon },
  { to: "/credentials", label: "Credentials", icon: LockKeyholeIcon },
]

export const orgNav: NavItem[] = [
  { to: "/org/members", label: "Members", icon: Users },
  { to: "/org/api-keys", label: "Org API Keys", icon: KeyRound },
  { to: "/org/settings", label: "Org Settings", icon: Building2 },
]

export const userNav: NavItem[] = [{ to: "/me", label: "Profile", icon: User2 }]

export const adminNav: NavItem[] = [
  { to: "/admin/users", label: "Users Admin", icon: Users },
  { to: "/admin/jobs", label: "Jobs Admin", icon: GrUserWorker },
  { to: "/admin/actions", label: "Actions Admin", icon: PickaxeIcon},
  { to: "/docs", label: "API Docs ", icon: SiSwagger, target: "_blank" },
]
